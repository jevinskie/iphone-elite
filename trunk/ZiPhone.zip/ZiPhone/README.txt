ZiPhone v1.0 by Zibri (http://zibree.blogspot.com)

Instructions:

Connect a brand new phone to the dock.
Run the program :)

Well, you can also use a restored phone...
Or a normal in use phone...
Well... whatever !

Unlock and Imei changer will work ONLY on 4.6 BL (112 and 113 ootb).

Jailbreak will work on any OS version.

Activation will work on any OS version, except for youtube on 1.0.X (I am lazy i know).

Details on how it works and WHY it works, will be soon available on http://www.iphone-elite.org

No 'dev-team' was directly involved with this work.
This program is based on the work of everyone who
believed in free software. (Thanks for the toolchain!)

Thanks to geohot for his latest work.
Thanks to milk for the windows GUI.
Thanks to Tissy for moral support.
Thanks to iphone-elite.org for support.
Thanks to Viper and Tifel and ortner for being so nice always.
Thanks to iRev for the picture above and to Mel Brooks for
producing and directing such a funny movie.

And thanks to iphoneelite.com for giving me so many laughs too :)

Namaste,
Zibri.

P.S.
As a side-effect, using this tool will revive many 'dead' basebands.
Just use the unlock option.

Thanks again to iRev for osx version.
